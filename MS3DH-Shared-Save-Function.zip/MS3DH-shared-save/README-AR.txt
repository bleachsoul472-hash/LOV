ملفات الحفظ المشترك لـ MS3DH (بدون ربط Discord)

مهم: هذه الملفات وحدها لا تكفي إذا كان index.html لا يرسل ويستقبل البيانات من /.netlify/functions/content.

انسخ المجلد netlify/functions إلى جذر مشروعك بحيث يصبح المسار:
netlify/functions/content.mjs
netlify/functions/_mongo.mjs

تأكد أن package.json في جذر المشروع يحتوي على dependency mongodb، مثل الملف المرفق.

في Netlify > Site configuration > Environment variables أضف:
MONGODB_URI = رابط الاتصال السري من MongoDB Atlas
MONGODB_DB_NAME = ms3dh
SITE_CONTENT_ADMIN_KEY = مفتاح طويل وسري تختاره أنت

بعدها أعد نشر الموقع (Deploy). لا تضع MONGODB_URI داخل HTML أو JavaScript.

تنبيه: هذا يضيف API للحفظ المشترك فقط. يجب أن تكون واجهة الموقع نفسها مهيأة لاستدعاء GET/PUT على /.netlify/functions/content؛ وإلا لن تحفظ أزرار الإدارة التعديلات عند الجميع. لا تشارك SITE_CONTENT_ADMIN_KEY مع الزوار.
